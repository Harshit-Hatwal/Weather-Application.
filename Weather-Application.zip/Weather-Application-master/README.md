**Weather-service**

Weather forecast application made with Node.js and Express.js server hosting.

Used Mapbox API and Weatherstack API for geolocation and weather data respectively.

Tech stack used - HTML, CSS, NodeJS, ExpressJS, Handlebars

**Production Link->** (https://phimanshu-weather-application.herokuapp.com/).

**Designed By-> Himanshu Pandey**
